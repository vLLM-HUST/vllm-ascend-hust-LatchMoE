# SEW-Offload Benchmark Suite

## sew_14gb_autoslots / mixed_chat

- Status: ok
- Median TTFT ms: 573.636
- Median TPOT ms: 55.329
- Output throughput tok/s: 16.524
