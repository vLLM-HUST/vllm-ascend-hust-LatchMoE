# sew_14gb_autoslots / mixed_chat

- Status: ok
- Stage: completed
- Server log: `/workspace/issue7-evidence/final-sha/repeat-3/sew-offload-ascend-v1-20260812T102042Z/sew_14gb_autoslots/mixed_chat/server.log`
- Client log: `/workspace/issue7-evidence/final-sha/repeat-3/sew-offload-ascend-v1-20260812T102042Z/sew_14gb_autoslots/mixed_chat/client.log`
- Benchmark JSON: `/workspace/issue7-evidence/final-sha/repeat-3/sew-offload-ascend-v1-20260812T102042Z/sew_14gb_autoslots/mixed_chat/benchmark.json`

## Metrics

- Successful requests: 11
- Failed requests: 0
- Median TTFT ms: 573.112
- Median TPOT ms: 53.555
- Output throughput tok/s: 17.075
