# SEW-Offload Benchmark Suite

## sew_14gb_autoslots / mixed_chat

- Status: ok
- Median TTFT ms: 573.112
- Median TPOT ms: 53.555
- Output throughput tok/s: 17.075
