# SEW-Offload Benchmark Suite

## sew_14gb_autoslots / mixed_chat

- Status: ok
- Median TTFT ms: 537.698
- Median TPOT ms: 55.933
- Output throughput tok/s: 16.500
