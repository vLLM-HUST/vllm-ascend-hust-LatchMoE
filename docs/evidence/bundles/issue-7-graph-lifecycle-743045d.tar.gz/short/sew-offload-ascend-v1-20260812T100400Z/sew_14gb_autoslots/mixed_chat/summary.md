# sew_14gb_autoslots / mixed_chat

- Status: ok
- Stage: completed
- Server log: `/workspace/issue7-evidence/final-sha/short/sew-offload-ascend-v1-20260812T100400Z/sew_14gb_autoslots/mixed_chat/server.log`
- Client log: `/workspace/issue7-evidence/final-sha/short/sew-offload-ascend-v1-20260812T100400Z/sew_14gb_autoslots/mixed_chat/client.log`
- Benchmark JSON: `/workspace/issue7-evidence/final-sha/short/sew-offload-ascend-v1-20260812T100400Z/sew_14gb_autoslots/mixed_chat/benchmark.json`

## Metrics

- Successful requests: 11
- Failed requests: 0
- Median TTFT ms: 572.610
- Median TPOT ms: 54.841
- Output throughput tok/s: 16.786
