# SEW-Offload Benchmark Suite

## sew_14gb_autoslots / mixed_chat

- Status: ok
- Median TTFT ms: 572.610
- Median TPOT ms: 54.841
- Output throughput tok/s: 16.786
