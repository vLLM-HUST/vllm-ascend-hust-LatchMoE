# sew_14gb_autoslots / smoke

- Status: ok
- Stage: completed
- Server log: `/workspace/issue7-evidence/final-sha/smoke/sew-offload-ascend-v1-20260812T100005Z/sew_14gb_autoslots/smoke/server.log`
- Client log: `/workspace/issue7-evidence/final-sha/smoke/sew-offload-ascend-v1-20260812T100005Z/sew_14gb_autoslots/smoke/client.log`
- Benchmark JSON: `/workspace/issue7-evidence/final-sha/smoke/sew-offload-ascend-v1-20260812T100005Z/sew_14gb_autoslots/smoke/benchmark.json`

## Metrics

- Successful requests: 1
- Failed requests: 0
- Median TTFT ms: 788.878
- Median TPOT ms: 48.441
- Output throughput tok/s: 6.795
