# SEW-Offload Benchmark Suite

## sew_14gb_autoslots / smoke

- Status: ok
- Median TTFT ms: 788.878
- Median TPOT ms: 48.441
- Output throughput tok/s: 6.795
