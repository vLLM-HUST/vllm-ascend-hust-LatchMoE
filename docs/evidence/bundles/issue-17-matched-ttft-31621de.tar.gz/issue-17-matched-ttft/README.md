# Issue #17 matched TTFT evidence

Run the repository verifier from this directory. Verify each unit against `units/pair-1-full_layer/benchmark.json`, then run the campaign verifier against `campaign.json`. `SHA256SUMS` covers every packaged evidence file.
